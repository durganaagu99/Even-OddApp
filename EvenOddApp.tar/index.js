import './index.css'

import {Component} from 'react'

class EvenOddApp extends Component {
  state = {count: 0}

  incrementCount = () => {
    const randomNumber = Math.ceil(Math.random() * 100)

    this.setState(prevState => ({count: prevState.count + randomNumber}))
  }

  render() {
    const {count} = this.state
    const text = count % 2 === 0 ? 'Even' : 'Odd'
    return (
      <div className="bg-container">
        <h1>Count {count}</h1>
        <p>Count is {text}</p>
        <button className="button" type="button" onClick={this.incrementCount}>
          Increment
        </button>
        <p>*Increase By Random Number Between 0 to 100</p>
      </div>
    )
  }
}
export default EvenOddApp
